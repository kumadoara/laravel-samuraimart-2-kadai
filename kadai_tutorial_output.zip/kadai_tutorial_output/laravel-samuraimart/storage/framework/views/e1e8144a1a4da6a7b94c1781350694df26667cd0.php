<?php echo e($slot, false); ?>: <?php echo e($url, false); ?>

<?php /**PATH C:\xampp\htdocs\laravel-samuraimart\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>