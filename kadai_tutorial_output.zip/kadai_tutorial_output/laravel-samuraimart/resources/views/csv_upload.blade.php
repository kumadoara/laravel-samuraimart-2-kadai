<div class="btn-group pull-right" style="margin-right: 10px">
    <a href="#" class="btn btn-sm btn-primary csv-import"><i class="fa fa-upload"></i><span class="hidden-xs">CSVインポート</span></a>
    <input type="file" id="files" name="product" style="display: none">
</div>
